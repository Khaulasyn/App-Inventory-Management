package com.project.inventorymanagement

import android.Manifest
import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date

class AddInventoryActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    private lateinit var noEditText: EditText
    private lateinit var itemEditText: EditText
    private lateinit var specificationEditText: EditText
    private lateinit var locationEditText: EditText
//    private lateinit var departmentEditText: EditText
//    private lateinit var categorySpinner: Spinner
    private lateinit var userEditText: EditText
    private lateinit var userIdEditText: EditText
    private lateinit var conditionEditText: EditText
    private lateinit var submitButton: Button
    private lateinit var code: String

    private lateinit var sharedPreferences: SharedPreferences

//    private lateinit var selectPhotoButton: Button
//    private lateinit var takePhotoButton: Button
//    private lateinit var photoImageView: ImageView
//    private val PICK_IMAGE_REQUEST = 1
//    private val REQUEST_IMAGE_CAPTURE = 2
//    private val REQUEST_PERMISSIONS = 3
//    private var photoUri: Uri? = null
//    private lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_inventory)

        sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        code = intent.getStringExtra("code") ?: ""

//        categorySpinner = findViewById(R.id.category_spinner)
        noEditText = findViewById(R.id.no)
        noEditText.setText(code)
        itemEditText = findViewById(R.id.item)
        specificationEditText = findViewById(R.id.specification)
        locationEditText = findViewById(R.id.location)
        userIdEditText = findViewById(R.id.user_id)
        val user_id = sharedPreferences.getString("user_id", "")
        userIdEditText.setText(user_id)
        userEditText = findViewById(R.id.user)
//        departmentEditText = findViewById(R.id.department)
//        categorySpinner = findViewById(R.id.category_spinner)
        conditionEditText = findViewById(R.id.condition)
        submitButton = findViewById(R.id.submit)

//        fetchCategories()

        // Set up submit button
        submitButton.setOnClickListener {
            submitInventoryData()
        }

//        selectPhotoButton = findViewById(R.id.selectPhotoButton)
//        takePhotoButton = findViewById(R.id.takePhotoButton)
//        photoImageView = findViewById(R.id.photo)
//
//        selectPhotoButton.setOnClickListener {
//            openGallery()
//        }
//
//        takePhotoButton.setOnClickListener {
//            if (checkPermissions()) {
//                openCamera()
//            }
//        }
    }
//    private fun fetchCategories() {
//        val request = Request.Builder()
//            .url("http://192.168.0.104:8000/api/categories/") // Change to your actual URL
//            .build()
//
//        client.newCall(request).enqueue(object : Callback {
//            override fun onFailure(call: Call, e: IOException) {
//                runOnUiThread {
//                    Toast.makeText(this@AddInventoryActivity, "Failed to load categories", Toast.LENGTH_SHORT).show()
//                }
//            }
//
//            override fun onResponse(call: Call, response: Response) {
//                if (!response.isSuccessful) {
//                    runOnUiThread {
//                        Toast.makeText(this@AddInventoryActivity, "Failed to load categories", Toast.LENGTH_SHORT).show()
//                    }
//                } else {
//                    val responseData = response.body?.string()
//                    if (responseData != null) {
//                        try {
//                            val jsonArray = JSONArray(responseData)
//                            val categories = mutableListOf<String>()
//                            for (i in 0 until jsonArray.length()) {
//                                val category = jsonArray.getJSONObject(i)
//                                categories.add(category.getString("name"))
//                            }
//                            runOnUiThread {
//                                val adapter = ArrayAdapter(this@AddInventoryActivity, android.R.layout.simple_spinner_item, categories)
//                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                                categorySpinner.adapter = adapter
//                            }
//                        } catch (e: JSONException) {
//                            runOnUiThread {
//                                Toast.makeText(this@AddInventoryActivity, "Failed to parse categories", Toast.LENGTH_SHORT).show()
//                            }
//                        }
//                    }
//                }
//            }
//        })
//    }

    private fun submitInventoryData() {

        val serverAddress = sharedPreferences.getString("server_address", "")
        if (serverAddress.isNullOrEmpty()) {
            Toast.makeText(this, "Please set the server address in settings", Toast.LENGTH_SHORT)
                .show()
            return
        }

        val no = noEditText.text.toString()
        val item = itemEditText.text.toString()
        val specification = specificationEditText.text.toString()
        val location = locationEditText.text.toString()
        val user = userEditText.text.toString()
//        val department = departmentEditText.text.toString()
//        val categoryId = categorySpinner.selectedItemId.toInt()
        val condition = conditionEditText.text.toString()

        val json = JSONObject().apply {
            put("no", no)
            put("name", item)
            put("specifications", specification)
            put("location", location)
            put("user", user)
            put("condition", condition)
//            put("department_id", department)
//            put("category_id", categoryId.toString())
        }

        val requestBody = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("$serverAddress/api/add_inventory/")
            .post(requestBody)
            .build()

        val token = sharedPreferences.getString("auth_token", null)
        val client = token?.let { getAuthenticatedClient(it) }

        if (client != null) {
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        Toast.makeText(this@AddInventoryActivity, "Gagal Menyimpan Data!", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    if (response.isSuccessful) {
                        runOnUiThread {
                            Toast.makeText(this@AddInventoryActivity, "Inventory Berhasil Disimpan", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@AddInventoryActivity, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        runOnUiThread {
                            Toast.makeText(this@AddInventoryActivity, "Error: ${response.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            })
        }
    }

    private fun getAuthenticatedClient(token: String): OkHttpClient {
        val sessionCookie = sharedPreferences.getString("session_cookie", null)

        return OkHttpClient.Builder()
            .cookieJar(MyCookieJar())
            .addInterceptor { chain ->
                val original = chain.request()
                val requestBuilder = original.newBuilder()
                    .header("Authorization", "Bearer $token")
                    .method(original.method, original.body)

                // Add session cookie to request if it exists
                sessionCookie?.let {
                    requestBuilder.header("Cookie", it)
                    Log.d(TAG, "Cookie $it")
                }

                val request = requestBuilder.build()
                chain.proceed(request)
            }
            .build()
    }
//    private fun openGallery() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        startActivityForResult(intent, PICK_IMAGE_REQUEST)
//    }

//    private fun openCamera() {
//        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//        if (intent.resolveActivity(packageManager) != null) {
//            val photoFile: File? = try {
//                createImageFile()
//            } catch (ex: IOException) {
//                null
//            }
//            photoFile?.also {
//                photoUri = FileProvider.getUriForFile(
//                    this,
//                    "${applicationContext.packageName}.fileprovider",
//                    it
//                )
//                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
//                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
//            }
//        }
//    }
//    @Throws(IOException::class)
//    private fun createImageFile(): File {
//        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
//        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
//        return File.createTempFile(
//            "JPEG_${timeStamp}_",
//            ".jpg",
//            storageDir
//        ).apply {
//            currentPhotoPath = absolutePath
//        }
//    }


//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_OK) {
//            when (requestCode) {
//                PICK_IMAGE_REQUEST -> {
//                    val selectedImage: Uri? = data?.data
//                    selectedImage?.let {
//                        photoImageView.setImageURI(it)
//                    }
//                }
//                REQUEST_IMAGE_CAPTURE -> {
//                    photoUri?.let {
//                        photoImageView.setImageURI(it)
//                    }
//                }
//            }
//        }
//    }
//
//    private fun checkPermissions(): Boolean {
//        val permissions = arrayOf(
//            Manifest.permission.CAMERA,
//            Manifest.permission.WRITE_EXTERNAL_STORAGE,
//            Manifest.permission.READ_EXTERNAL_STORAGE
//        )
//
//        val missingPermissions = permissions.filter {
//            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
//        }
//
//        return if (missingPermissions.isNotEmpty()) {
//            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), REQUEST_PERMISSIONS)
//            false
//        } else {
//            true
//        }
//    }
//
//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == REQUEST_PERMISSIONS && grantResults.isNotEmpty()) {
//            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
//            if (allGranted) {
//                openCamera()
//            }
//        }
//    }
}